'use strict';

const mysql = require('mysql2');

//local mysql db connection
/*const pool =  mysql.createPool({
    host: 'localhost',
    user: 'root',
    password : 'root',
    database: 'BWS',
   
});*/

/* dev server mysql connection */
const pool =  mysql.createPool({
    host: 'localhost',
    port : '3306',
    user: 'brent',
    password : 'bRentSch00l',
    database: 'brentwood',
    connectionLimit: 100

});
module.exports = pool.promise();
