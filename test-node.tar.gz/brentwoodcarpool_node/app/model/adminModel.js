'user strict';
const connection = require('../../db.js');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const mail = require('../utils/mail');

/* login method */

module.exports.login = async (email, password) => {
   
    try {

       var  conn = await connection.getConnection();

        console.log(email);
        console.log(password);
        //find user in users table
        const [rows, fields] = await conn.execute(`select id,first_name,last_name,password from admin_user where email = ? `, [email]);
        if (rows.length > 0) {

            const isEqual = await bcrypt.compare(password, rows[0].password);
            if (!isEqual) {
                return {
                    message: "Please enter correct password.",
                    loggedin: 0

                };
            }
            else {
                //genrate json web token
                const token = jwt.sign({
                    email: email,
                    user_id: rows[0].id
                }, "ashsupersecrate", {
                    expiresIn: "1 hr"
                });

                return {
                    message: "loggedin!!!",
                    token: token,
                    userId: rows[0].id,
                    first_name: rows[0].first_name,
                    last_name: rows[0].last_name,
                    loggedin: 1
                };
            }
        }

        return {
            message: "Please enter correct email id.",
            loggedin: 0

        };

        conn.release();

    } catch (error) {
        conn.release();

    }

}

/* get comment data */

module.exports.getComment = async () => {
 
    try {
        var conn = await connection.getConnection();

        const [rows1, fields] = await conn.query('SELECT id,driver_id,driver_type,uid,user_type,comment,created_dt FROM `feedback`');

        let query = "";
        result = [];
        if (rows1.length > 0) {
            for (i = 0; i < rows1.length; i++) {
                if (rows1[i].driver_type == 1 && rows1[i].user_type == 1) {
                    //use user table for join data
                    query = `SELECT u.user_type as 'driver_user_type',u.uid as 'driver_user_id',f.comment,date_format(f.created_dt,'%m-%d-%Y') as date,u.first_name as 'driver_first_name',u.last_name as 'driver_last_name',u.user_email as 'driver_email',u1.first_name as 'user_first_name',u1.last_name as 'user_last_name',u1.user_email as 'user_email' FROM feedback f inner join users u on u.uid=f.driver_id Inner Join users u1 on u1.uid=f.uid
                    where f.id = ${rows1[i].id} and u.is_deleted = '0'`;
                    //console.log(query);
                }
                else if (rows1[i].driver_type == 2 && rows1[i].user_type == 2) {
                    //use parents table for join
                    query = `SELECT u.user_type as 'driver_user_type',u.parent_user_id as 'driver_user_id',f.comment,date_format(f.created_dt,'%m-%d-%Y') as date,u.first_name as 'driver_first_name',u.last_name as 'driver_last_name',u.email as 'driver_email',u1.first_name as 'user_first_name',u1.last_name as 'user_last_name',u1.email as 'user_email' FROM feedback f inner join parents u on u.parent_user_id=f.driver_id Inner Join parents u1 on u1.parent_user_id=f.uid  where f.id = ${rows1[i].id} and u.is_deleted = '0'`;
                }
                else if (rows1[i].driver_type == 1 && rows1[i].user_type == 2) {
                    query = `SELECT u.user_type as 'driver_user_type',u.uid as 'driver_user_id',fb.comment,date_format(fb.created_dt,'%m-%d-%Y') as date, u.first_name as 'driver_first_name',u.last_name as 'driver_last_name',u.user_email as 'driver_email',u1.first_name as 'user_first_name',u1.last_name as 'user_last_name',u1.email as 'user_email' from feedback fb inner join users u on fb.driver_id = u.uid inner join parents u1 on fb.uid = u1.parent_user_id  where fb.id = ${rows1[i].id} and u.is_deleted = '0'`;

                }
                else {
                    query = `SELECT u.user_type as 'driver_user_type',u.parent_user_id as 'driver_user_id',fb.comment, date_format(fb.created_dt,'%m-%d-%Y') as date, u.first_name as 'driver_first_name',u.last_name as 'driver_last_name',u.email as 'driver_email',u1.first_name as 'user_first_name',u1.last_name as 'user_last_name',u1.user_email as 'user_email'  FROM feedback fb inner join parents u on fb.driver_id = u.parent_user_id inner join users u1 on fb.uid = u1.uid  where fb.id = ${rows1[i].id} and u.is_deleted = '0'`;


                }
                const [rows, fields] = await conn.execute(query);
                result[i] = rows[0];

            }
            return result;
            conn.release();
        }

    } catch (error) {
        conn.release();
        console.log(error);

    }


}

/*** method for block and unblock user  */

module.exports.blockUnblock = async (is_block, user_type, email) => {
    
    try {
       var  conn = await connection.getConnection();
        //if user type is 1 and is_block=1
        if (user_type == 1 && is_block == 1) {
            const result = await conn.execute(`UPDATE users SET is_deleted = '1' WHERE user_email=? `, [email]);
            console.log(result[0].affectedRows)
            if (result[0].affectedRows) {
                return true;
            }
        }
        else if (user_type == 1 && is_block == 0) {
            const result = await conn.execute(`UPDATE users SET is_deleted = '0' WHERE user_email =? `, [email]);
            if (result[0].affectedRows) {
                return true;
            }

        }
        else if (user_type == 2 && is_block == 1) {
            const result = await conn.execute(`UPDATE parents SET is_deleted = '1' WHERE email=? `, [email]);
            if (result[0].affectedRows) {
                return true;
            }


        }
        else {
            const result = await conn.execute(`UPDATE parents SET is_deleted = '0' WHERE email=? `, [email]);
            if (result[0].affectedRows) {
                return true;
            }

        }

        conn.release();

    } catch (error) {
        conn.release();

    }


}

/*** geting blocked user */

module.exports.blockedUser = async () => {
       
    try {
        var  conn = await connection.getConnection();
        const [rows, columns] = await conn.execute("SELECT CONCAT(first_name, ' ' ,last_name) as name,user_email as email,user_type  FROM brentwood.users where is_deleted ='1' UNION SELECT CONCAT(first_name,' ' ,last_name) as name,email as email,user_type  FROM brentwood.parents where is_deleted ='1'");
        conn.release();
        return rows;
    } catch (error) {

        conn.release();

    }

}


module.exports.pendingRequest = async () => {
        console.log("dddd",await connection.Pool);
    try {
        var conn = await connection.getConnection();
        const [rows, columns] = await conn.execute("SELECT date_format(u1.created_dt,'%m-%d-%Y') as created_dt ,u1.first_name,u1.last_name,u.email,u1.email as 'additionaldriver',u1.added_by  FROM brentwood.parents u inner join brentwood.parents u1 on u.parent_user_id = u1.added_by where u1.verified = '0' and u1.is_deleted = '0' and u1.user_type = '3' ");
        conn.release();
        return rows;
    } catch (error) {
        console.log(error);
        conn.release();
    }


}

module.exports.pendingRequestApproveReject = async (action, email,driver_first_name) => {
   
    try {
       var conn = await connection.getConnection();
        //console.log(action,email);
        //const conn = await connection.getConnection();
        if (action == 1) //approve user
        {

            const result = await conn.execute(`UPDATE parents SET verified = '1' WHERE email=? `, [email]);
            console.log(result[0].affectedRows)
            if (result[0].affectedRows) {
                mailApproveReject(email,action,driver_first_name);
                return { status: 1, message: "user approved successfuly" };
            }
        }
        else  // reject user 
        {
            const result = await conn.execute(`UPDATE parents SET is_deleted = '1' WHERE email=? `, [email]);
            console.log(result[0].affectedRows)
            if (result[0].affectedRows) {
                mailApproveReject(email,action,driver_first_name);
                return { status: 1, message: "user rejected successfuly" };
            }
        }

        conn.release();

    } catch (error) {
       console.log(error);
        conn.release();

    }
}

module.exports.pendingRequestHistory = async () => {
   
try {
    var conn = await connection.getConnection();
    const [rows, columns] = await conn.execute("SELECT u1.verified ,u1.is_deleted,date_format(u1.created_dt,'%m-%d-%Y') as created_dt ,u1.first_name,u1.last_name,u.email,u1.email as 'additionaldriver',u1.added_by  FROM brentwood.parents u inner join brentwood.parents u1 on u.parent_user_id = u1.added_by where u1.is_deleted = '1' OR u1.verified = '1' AND u1.user_type = '3'");
    conn.release();
    return rows;
} catch (error) {
    conn.release();
}


}

/** mail in case of approved driver */

function mailApproveReject(email,type,driver_first_name,)
{
if(type == 1)
{
    var message = `<table cellpadding="0" cellspacing="0" style="font-family:'Labtop',sans-serif;font-size:14px;border-radius:3px;background:#fff;margin:0;padding:0;border:1px solid #e9e9e9;margin:0 auto;max-width:700px" width="100%">
    <div style="padding-left:300px;">
    <img src="http://64.150.183.17:1013/brentwood-logo.png" style="width:120px;margin-top:20px;">
    </div>
        <tbody>
            <tr style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0;background:white">
                <td colspan="3" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:20px;border-top:10px solid #ffffff" valign="top">
                <table cellpadding="0" cellspacing="0" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0" width="100%">
                    <tbody>
                        <tr>
                            <td width="15%"></td>
                            <td style="font-weight:300;vertical-align:top;padding-bottom:25px;color:dimgray;width:70%;padding:10px;text-align:left" valign="top">
                            <p style="font-size:16px">Hello ${driver_first_name},</p>
    
                            <p style="font-size:16px">Thanks for Joining Brentwood.</p>
    
                            <p style="font-size:16px">Admin has apporved you as a driver ,To complete your Brentwood registration signup with required details.</p>
    
  
    
                            <p style="font-size:16px">All the best,</p>
    
                            <p style="font-size:16px">Brentwood Team</p>
                            </td>
                            <td width="15%"></td>
    </tr>
                    </tbody>
                </table>
                                    </td>
            </tr>
        </tbody>
    </table>`;
}
else
{
    var message = `<table cellpadding="0" cellspacing="0" style="font-family:'Labtop',sans-serif;font-size:14px;border-radius:3px;background:#fff;margin:0;padding:0;border:1px solid #e9e9e9;margin:0 auto;max-width:700px" width="100%">
    <div style="padding-left:300px;">
    <img src="http://64.150.183.17:1013/brentwood-logo.png" style="width:120px;margin-top:20px;">
    </div>
        <tbody>
            <tr style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0;background:white">
                <td colspan="3" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:20px;border-top:10px solid #ffffff" valign="top">
                <table cellpadding="0" cellspacing="0" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0" width="100%">
                    <tbody>
                        <tr>
                            <td width="15%"></td>
                            <td style="font-weight:300;vertical-align:top;padding-bottom:25px;color:dimgray;width:70%;padding:10px;text-align:left" valign="top">
                            <p style="font-size:16px">Hello ${driver_first_name},</p>
    
                            <p style="font-size:16px"></p>
    
                            <p style="font-size:16px">Admin has Rejected your application as a driver,Please contact to him if you have any query.</p>
    
  
    
                            <p style="font-size:16px">All the best,</p>
    
                            <p style="font-size:16px">Brentwood Team</p>
                            </td>
                            <td width="15%"></td>
    </tr>
                    </tbody>
                </table>
                                    </td>
            </tr>
        </tbody>
    </table>`;
}

const from = 'Brentwood Admin<admin@brentwood.com>';
    const to = email;
    const subject = "Mail from Brentwood Admin";
    
    const result =  mail.mailfunction(from, to, subject, message);
    console.log(result);
    if (result.status == 1) {
        return true;
    }
    else {
       return false;
    }

}






