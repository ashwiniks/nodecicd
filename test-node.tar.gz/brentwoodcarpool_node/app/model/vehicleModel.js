'use strict';
const connection = require('../../db.js');





/* get vehicle */

module.exports.getVehicle = async (req) => {
    try {
        const [rows, fields] = await connection.execute('SELECT * FROM `vehicle` WHERE is_deleted = "0" AND `uid` = ? AND user_type = ?', [req.uid, req.user_type]);
        return rows;
    }
    catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }

    }

}

/* add vehicle */

module.exports.addVehicle = async (vehicle) => {
    var conn = await connection.getConnection();
    if(vehicle.user_type==1) {
        const [rows, fields] = await conn.execute(`SELECT DATE_FORMAT(NOW(), '%Y') - DATE_FORMAT(dob, '%Y') - (DATE_FORMAT(NOW(), '00-%m-%d') < DATE_FORMAT(dob, '00-%m-%d')) AS age FROM users WHERE uid = ?`, [vehicle.uid]);
        if(rows[0].age < "18") {
            conn.release();
            return 2;
        } else {
            let [ResultSetHeader] = await conn.execute('insert into `vehicle` (`uid`,`user_type`,`manufacturing_year`,`make`,`model`,`license_no`) values(?,?,?,?,?,?)', [vehicle.uid, vehicle.user_type, vehicle.manufacturing_year, vehicle.make, vehicle.model, vehicle.license_no]);
            if (ResultSetHeader.insertId) {
                conn.release();
                return 1;
            }
            else {
                conn.release();
                return 0;
            } 
        }
    } else {
        let [ResultSetHeader] = await conn.execute('insert into `vehicle` (`uid`,`user_type`,`manufacturing_year`,`make`,`model`,`license_no`) values(?,?,?,?,?,?)', [vehicle.uid, vehicle.user_type, vehicle.manufacturing_year, vehicle.make, vehicle.model, vehicle.license_no]);
        if (ResultSetHeader.insertId) {
            conn.release();
            return 1;
        }
        else {
            conn.release();
            return 0;
        }
    }
}


/* update vehicle */

module.exports.getVehicleById = async (id) => {
    var conn = await connection.getConnection();
    const [rows, fields] = await connection.execute('SELECT * FROM `vehicle` WHERE is_deleted = "0" AND `id` = ?', [id]);
    conn.release();
    if(rows[0].id){
        return 1;
    }
    else {
        return 0;
    }
}

/* update vehicle */

module.exports.updateVehicle = async (res, id) => {
    var conn = await connection.getConnection();
    const [rows, fields] = await connection.execute('UPDATE `vehicle` SET manufacturing_year = ?,make=?, model = ? ,license_no = ? WHERE id = ?', [res.manufacturing_year, res.make, res.model, res.license_no, id]);
    conn.release();
    if(rows.affectedRows){
        return 1;
    }
    else {
      return 0 ;
    }
}

/* Delete Vehicle */
module.exports.delete_vehicle = async (res, id) => {
    var conn = await connection.getConnection();
    const [rows, fields] = await connection.execute('UPDATE `vehicle` SET is_deleted ="1" WHERE id = ? AND uid= ? AND user_type= ?', [res.vehicle_id, res.uid, res.user_type]);
    conn.release();
    if(rows.affectedRows){
        return 1;
    }
    else {
      return 0 ;
    }
}


