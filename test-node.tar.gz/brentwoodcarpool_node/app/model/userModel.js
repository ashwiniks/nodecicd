'user strict';
const connection = require('../../db.js');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const  dateFormat = require('dateformat');






module.exports.checkUser = async (user) => {

    try {
        var conn = await connection.getConnection();
        if (user.user_type == 1) { // user_type 1 for student
            //check student is greater then 13  year
            let today = new Date();
            let birthDate = new Date(user.dob);
            let age = today.getFullYear() - birthDate.getFullYear();
            let m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            const [rows, fields] = await conn.execute('SELECT * FROM `users` WHERE `user_email` = ? AND `dob` =  ?', [user.emailAddress, user.dob]);
            if (rows.length > 0) {
                if (age < 13) {
                    const password = await bcrypt.hash(user.user_pass, 12);
                    let result = await conn.execute(`UPDATE users SET user_pass = '${password}' WHERE user_email=? `, [user.emailAddress]);
                    conn.release();
                    return {
                        message: "below 13 ? please contact admin", status: 0
                    }
                } else {
                    conn.release();
                    return {
                        message: "user found in school database", status: 1
                    };    
                }
            }
            else {
                conn.release();
                return {
                    message: "user not found in school database", status: 0
                };
            }
        }
        else {
            //check parent exist in users table(school database)
            const [rows, fields] = await conn.execute('SELECT * FROM `parents` WHERE `email` = ? ', [user.emailAddress]);
            conn.release();
            if (rows.length > 0) {
                return {
                    message: "user found in school database", status: 1
                };
            }
            else {
                return {
                    message: "user not found in school database", status: 0
                };;
            }
        }
    } catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
    }
};

/* register user in local database */

module.exports.signUp = async (user) => {
    try {
        var conn = await connection.getConnection();
        // we can set expiration time using sync
        const token = jwt.sign({ email: user.emailAddress, user_type: user.user_type }, 'brentwoodsecreatekey', { expiresIn:"7d" });
        const subject = "Please confirm your Email account";
        const URL = "http://64.150.183.17:1013/auth/verify?token=" + token;
        const text = "Hello,<br> Please Click on the link to verify your email.<br><a href=" + URL + ">Click here to verify</a>";
        //check for already registerd student
        if (user.user_type == 1) {
            const [rows, fields] = await conn.execute('SELECT `first_name`,`is_registered` FROM `users` WHERE `user_email` = ?', [user.emailAddress]);
            if (rows[0].is_registered == 1) {
                conn.release();
                return 0;
            }
            else {
                const password = await bcrypt.hash(user.user_pass, 12);
                console.log(password);
                let result = await conn.execute(`UPDATE users SET user_pass = '${password}',is_registered = '1' WHERE user_email=? `, [user.emailAddress]);
                mailfunction('Brentwood Admin<admin@brentwood.com>', user.emailAddress, subject, rows[0].first_name,URL);
                conn.release();
                return 1;
            }
        }
        else {
            const [rows, fields] = await conn.execute('SELECT `first_name`,`is_registered` FROM `parents` WHERE `email` = ?', [user.emailAddress]);
            if (rows[0].is_registered == 1) {
                conn.release();
                return 0;
            }
            else {
                const password = await bcrypt.hash(user.user_pass, 12);
                let result = await conn.execute(`UPDATE parents SET password= '${password}',is_registered = '1' WHERE email=? `, [user.emailAddress]);
                mailfunction('Brentwood Admin<admin@brentwood.com>', user.emailAddress, subject, rows[0].first_name,URL);
                conn.release();
                return 1;
            }
        }
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/* request a ride */

module.exports.requestRide = async (res) => {
    try {
        var conn = await connection.getConnection();
        for (i = 0; i < res.start_date.length; i++) {
            const [rows, fields] = await conn.execute(`select * from offer_rides where uid = ${res.uid} AND user_type='${res.user_type}' and is_deleted = '0'  and start_date = '${res.start_date[i]}'`);
            if (rows.length > 0) {
                return { statusCode: 422, message: `you have a offered ride on ${dateFormat(res.start_date[i], "mm/dd/yy")}` } ;
            }
        }
        for (i = 0; i < res.start_date.length; i++) {
            var [row, field] =  await conn.execute(`SELECT * FROM find_rides WHERE uid='${res.uid}' AND user_type='${res.user_type}' AND is_deleted='0' AND start_date ='${res.start_date[i]}'`);
            if(row.length == 1) {
                var ti = new Date(2001,1,1,row[0].start_time.split(":")[0],row[0].start_time.split(":")[1]) ;
                ti = ("0"+ti.getHours(ti.setHours(ti.getHours()+3))).slice(-2)+":"+row[0].start_time.split(":")[1]+":"+row[0].start_time.split(":")[2] ;
                var beforeti = new Date(2001,1,1,row[0].start_time.split(":")[0],row[0].start_time.split(":")[1]) ;
                beforeti = ("0"+beforeti.getHours(beforeti.setHours(beforeti.getHours()-3))).slice(-2)+":"+row[0].start_time.split(":")[1]+":"+row[0].start_time.split(":")[2] ;
                if(row[0].start_time.split(":")[0] < 10) {
                    var serverTime = "0"+row[0].start_time.split(":")[0]+":"+row[0].start_time.split(":")[1]+":"+row[0].start_time.split(":")[2] ;
                } else {
                    var serverTime = row[0].start_time ;
                }
                //console.log((res.start_time >= beforeti && res.start_time <= ti) || (serverTime>='00:00:00' && serverTime <='03:00:00' && res.start_time>='00:00:00' && res.start_time <='03:00:00') || (serverTime>='20:59:59' && serverTime <='23:59:59' && res.start_time>='20:59:59' && res.start_time <='23:59:59') );
                if((res.start_time >= beforeti && res.start_time <= ti) || (serverTime>='00:00:00' && serverTime <='03:00:00' && res.start_time>='00:00:00' && res.start_time <='03:00:00') || (serverTime>='20:59:59' && serverTime <='23:59:59' && res.start_time>='20:59:59' && res.start_time <='23:59:59')) {
                    conn.release();
                    return { statusCode: 422, message: `You can not book another ride within 3 hours ${serverTime}`} ;    
                }
            }
            else if(row.length > 1) {
                conn.release();
                return { statusCode: 422, message: `You can not book more than two ride on ${ dateFormat(res.start_date[i], "mm/dd/yy")}`} ;
            } else {
                continue ;
            }
        }
        data = [];
        res.start_date.forEach(element => {
            data.push([res.uid, res.start_point_lat, res.start_point_long, res.start_point, res.end_point, res.end_point_lat, res.end_point_long, element, res.start_time, res.seats, res.special_request, res.user_type]);
        });
        let [ResultSetHeader] = await conn.query("insert into `find_rides` (`uid`,`start_point_lat`,`start_point_long`,`start_point`,`end_point`,`end_point_lat`,`end_point_long`,`start_date`,`start_time`,`seats`,`special_request`, `user_type`) values?", [data]);
        conn.release();
        return ResultSetHeader.insertId;
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }

}

/* offer a ride */

module.exports.offerRide = async (res) => {
    try {
        var conn = await connection.getConnection();
        for (i = 0; i < res.start_date.length; i++) {
            const [rows, fields] = await conn.execute(`select * from find_rides where uid = ${res.uid} AND user_type='${res.user_type}' and is_deleted = '0'  and start_date = '${res.start_date[i]}'`);
            if (rows.length > 0) {
                conn.release();
                return { statusCode: 422, message: `you have requested a ride on ${dateFormat(res.start_date[i], "mm/dd/yy")}` }
            }
        }
        for (i = 0; i < res.start_date.length; i++) {
            var [row, field] =  await conn.execute(`SELECT * FROM offer_rides WHERE uid='${res.uid}' AND user_type='${res.user_type}' AND is_deleted='0' AND start_date ='${res.start_date[i]}'`);
            if(row.length == 1) {
                var ti = new Date(2001,1,1,row[0].start_time.split(":")[0],row[0].start_time.split(":")[1]) ;
                ti = ("0"+ti.getHours(ti.setHours(ti.getHours()+4))).slice(-2)+":"+row[0].start_time.split(":")[1]+":"+row[0].start_time.split(":")[2] ;
                var beforeti = new Date(2001,1,1,row[0].start_time.split(":")[0],row[0].start_time.split(":")[1]) ;
                beforeti = ("0"+beforeti.getHours(beforeti.setHours(beforeti.getHours()-3))).slice(-2)+":"+row[0].start_time.split(":")[1]+":"+row[0].start_time.split(":")[2] ;
                if(row[0].start_time.split(":")[0] < 10) {
                    var serverTime = "0"+row[0].start_time.split(":")[0]+":"+row[0].start_time.split(":")[1]+":"+row[0].start_time.split(":")[2] ;
                } else {
                    var serverTime = row[0].start_time ;
                }
                if((res.start_time >=serverTime && res.start_time <= ti) || (res.start_time <=serverTime && res.start_time >= beforeti) || (serverTime>='00:00:00' && serverTime <='03:00:00' && res.start_time>='00:00:00' && res.start_time <='03:00:00') || (serverTime>='20:59:59' && serverTime <='23:59:59' && res.start_time>='20:59:59' && res.start_time <='23:59:59')) {
                    conn.release();
                    return { statusCode: 422, message: `You can not book another ride within 3 hours ${res.start_time}`} ;    
                }
            } else if(row.length > 1) {
                conn.release();
                return { statusCode: 422, message: `You can not book more than two ride on ${dateFormat(res.start_date[i], "mm/dd/yy")}`} ;
            } else {
                continue ;
            }
        }
        data1 = [];
        res.start_date.forEach(element => {
            data1.push([res.uid, res.start_point_lat, res.start_point_long, res.start_point, res.end_point, res.end_point_lat, res.end_point_long, element, res.start_time, res.seats, res.seats, res.vehicle_id, res.user_type, res.route_lat_long]);
        });
        let [ResultSetHeader] = await conn.query('insert into `offer_rides` (`uid`,`start_point_lat`,`start_point_long`,`start_point`,`end_point`,`end_point_lat`,`end_point_long`,`start_date`,`start_time`,`seats`,`seat_available`,`vehicle_id`,`user_type`,`route_lat_long`) values?', [data1]);
        conn.release();
        return ResultSetHeader.insertId;
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/* Cancel a ride.*/

module.exports.cancelRide = async (res) => {
    try {
        var conn = await connection.getConnection();
        if (res.request_type == "request") {
            let result = await conn.execute('UPDATE find_rides SET is_deleted= "1" WHERE uid=? AND user_type=? AND id=? ', [res.uid, res.user_type, res.ride_id]);
            conn.release();
            if(result[0].changedRows == 1) {
                return 1;    
            } else {
                return { statusCode: 500, message: `Record doesn't match with our datbase.`} ;     
            }
            
        } else if (res.request_type == "offer") {
            let result = await conn.execute('UPDATE offer_rides SET is_deleted= "1" WHERE uid =? AND user_type=? AND id=? ', [res.uid, res.user_type, res.ride_id]);
            conn.release();
            if(result[0].changedRows == 1) {
                return 1;    
            } else {
                return { statusCode: 500, message: `Record doesn't match with our datbase.`} ;     
            }
        } else {
            return { statusCode: 500, message: `Invalid request type.`} ;
        }
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/* List user requested ride.*/
module.exports.listRequestRide = async (req) => {
    try {
        var conn = await connection.getConnection();
        if (req.start_date) {
            if (req.request_type == 3) {
                //const query = connection.format('SELECT R.*,Concat(V.first_name," ",V.last_name) AS driver_name FROM `find_rides` AS R Left JOIN users AS V ON V.uid=R.driver_id  WHERE R.start_date= ? AND R.`uid` = ?', [req.start_date, req.uid]);
                var [rows, fields] = await conn.execute('SELECT R.*,Concat(V.first_name," ",V.last_name) AS driver_name FROM `find_rides` AS R Left JOIN parents AS V ON V.parent_user_id=R.driver_id  WHERE R.start_date= ? AND R.`uid` = ?', [req.start_date, req.uid]);
            } else {
                var [rows, fields] = await conn.execute('SELECT R.*,Concat(V.first_name," ",V.last_name) AS driver_name FROM `find_rides` AS R Left JOIN parents AS V ON V.parent_user_id=R.driver_id  WHERE R.start_date= ? AND R.`is_deleted` = ? AND R.`uid` = ? ', [req.start_date, req.request_type, req.uid]);
            }
            conn.release();
            return rows;
        }
        else {
            if (req.request_type == 3) {
                //const query = connection.format('SELECT R.*,Concat(V.first_name," ",V.last_name) AS driver_name FROM `find_rides` AS R Left JOIN users AS V ON V.uid=R.driver_id  WHERE  R.`uid` = ?', [req.uid]);
                var [rows, fields] = await conn.execute('SELECT R.*,Concat(V.first_name," ",V.last_name) AS driver_name FROM `find_rides` AS R Left JOIN parents AS V ON V.parent_user_id=R.driver_id  WHERE  R.`uid` = ?', [req.uid]);
                
            } else {
                var [rows, fields] = await conn.execute('SELECT R.*,Concat(V.first_name," ",V.last_name) AS driver_name FROM `find_rides` AS R Left JOIN parents AS V ON V.parent_user_id=R.driver_id  WHERE  R.`is_deleted` = ? AND R.`uid` = ? ', [req.request_type, req.uid]);
            }
            conn.release();
            return rows;
        }
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/* List user offer ride.*/
module.exports.listOfferRide = async (req) => {
    try {
        var conn = await connection.getConnection();
        if (req.request_type == 3) {
            var [rows, fields] = await conn.execute('SELECT R.*,V.make, V.model FROM `offer_rides` AS R INNER JOIN vehicle AS V ON V.id=R.vehicle_id WHERE  R.uid = ?', [req.uid]);
        } else {
            var [rows, fields] = await conn.execute('SELECT R.*,V.make, V.model FROM `offer_rides` AS R INNER JOIN vehicle AS V ON V.id=R.vehicle_id WHERE R.is_deleted=? AND R.uid = ?', [req.request_type, req.uid]);
        }
        conn.release();
        return rows;
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/* New match request. */
module.exports.newRequest = async (req) => {
    try {
        var conn = await connection.getConnection();
        // select driver's offer ride
        const [rows, fields] = await conn.execute('SELECT R.id, R.start_point, R.start_point_lat, R.start_point_long, R.end_point, R.end_point_lat, R.end_point_long, R.start_date, R.start_time, R.seats, R.seat_available, R.route_lat_long, R.created_dt, R.vehicle_id, V.make, V.model FROM `offer_rides` AS R INNER JOIN vehicle AS V ON V.id=R.vehicle_id WHERE  R.uid = ? AND R.start_date = ? AND R.user_type=? AND R.is_deleted = ?', [req.driver_id, req.start_date, req.user_type, '0']);
        //console.log("First Ride =="+rows[0].start_time+" Second Ride =="+ rows[1].start_time);
        //const offerData = rows;

        if (rows.length > 0) {
            console.log(rows.length);
            console.log("hererer");
            if (rows.length == 2) {
                console.log("hererer");
                /* data for the first ride.*/
                if (rows[0].seat_available == 0) {
                    var [row1, field1] = await conn.execute(`SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN users AS U ON U.uid=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id=${req.driver_id} AND user_type= ${req.user_type}) AND FR.is_deleted="0" AND U.is_deleted="0" AND FR.start_date= '${req.start_date}' AND FR.is_booked = "1" 
                    UNION 
                    
                    SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN parents AS U ON U.parent_user_id = FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id=${req.driver_id} AND user_type= ${req.user_type}) AND FR.is_deleted="0" AND U.is_deleted="0" AND FR.start_date= '${req.start_date}' AND FR.is_booked = "1" `);
                }
                else {

                    var [row1, field1] = await conn.execute(`SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name,  FROM find_rides AS FR INNER JOIN users AS U ON U.uid=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id= 
                        ${req.driver_id} AND user_type=${req.user_type}) AND FR.is_deleted="0"  AND U.is_deleted="0" AND FR.start_date= '${req.start_date}' AND FR.start_time >= '${rows[0].start_time}' AND FR.start_time <= '${rows[1].start_time}' AND FR.seats <= ${rows[0].seat_available}
                    UNION
                    SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name  FROM find_rides AS FR INNER JOIN parents AS U ON U.parent_user_id = FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id= ${req.driver_id} AND user_type= ${req.user_type}) AND FR.is_deleted="0"  AND U.is_deleted="0" AND FR.start_date= '${req.start_date}' AND FR.start_time >= '${rows[0].start_time}' AND FR.start_time <= '${rows[1].start_time}' AND FR.seats <= ${rows[0].seat_available}
                    `);

                }
                /* data for second ride */
                if (rows[1].seat_available == 0) {
                    var [row2, field2] = await conn.execute(`SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN users AS U ON U.uid=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id= ${req.driver_id} AND user_type=${req.user_type}) AND FR.is_deleted="0" AND U.is_deleted="0" AND FR.start_date='${req.start_date}' AND FR.is_booked = "1" 
                     UNION
                    
                    SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN parents AS U ON U.parent_user_id=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id= ${req.driver_id} AND user_type=${req.user_type}) AND FR.is_deleted="0" AND U.is_deleted="0" AND FR.start_date='${req.start_date}' AND FR.is_booked = "1" 
                    
                    `);
                }
                else {
                    var ti = new Date(2001, 1, 1, rows[1].start_time.split(":")[0], rows[1].start_time.split(":")[1]);
                    ti = ("0" + ti.getHours(ti.setHours(ti.getHours() + 4))).slice(-2) + ":" + rows[1].start_time.split(":")[1] + ":" + rows[1].start_time.split(":")[2];
                    /*if(rows[1].start_time.split(":")[0] < 10) {
                        var serverTime = "0"+rows[1].start_time.split(":")[0]+":"+rows[1].start_time.split(":")[1]+":"+rows[1].start_time.split(":")[2];
                    } else {
                        var serverTime = rows[1].start_time ;
                    }*/
                    var [row2, field2] = await conn.execute(`SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN users AS U ON U.uid=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id= ${req.driver_id} AND user_type=${req.user_type}) AND FR.is_deleted="0"  AND U.is_deleted="0" AND FR.start_date='${req.start_date}' AND FR.start_time >='${rows[1].start_time}' AND FR.start_time <='${ti}' AND FR.seats <= ${rows[0].seat_available}
                    UNION

                    SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN parents AS U ON U.parent_user_id=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id= ${req.driver_id} AND user_type=${req.user_type}) AND FR.is_deleted="0"  AND U.is_deleted="0" AND FR.start_date='${req.start_date}' AND FR.start_time >='${rows[1].start_time}' AND FR.start_time <='${ti}' AND FR.seats <= ${rows[0].seat_available}
                `);
                }
                conn.release();
                return {
                    offered: 1, "data":
                        [
                            {
                                "firstRide": [{
                                    "offerRide":
                                    {
                                        "id": rows[0].id,
                                        "start_point": rows[0].start_point,
                                        "start_point_lat": rows[0].start_point_lat,
                                        "start_point_long": rows[0].start_point_long,
                                        "end_point": rows[0].end_point,
                                        "end_point_lat": rows[0].end_point_lat,
                                        "end_point_long": rows[0].end_point_long,
                                        "start_date": rows[0].start_date,
                                        "start_time": rows[0].start_time,
                                        "seats": rows[0].seats,
                                        "seat_available": rows[0].seat_available,
                                        "route_lat_long": rows[0].route_lat_long,
                                        "created_dt": rows[0].created_dt,
                                        "vehicle_id": rows[0].vehicle_id,
                                        "make": rows[0].make,
                                        "model": rows[0].model
                                    },
                                    "findRide": row1
                                }],
                                "secondRide": [{
                                    "offerRide":
                                    {
                                        "id": rows[1].id,
                                        "start_point": rows[1].start_point,
                                        "start_point_lat": rows[1].start_point_lat,
                                        "start_point_long": rows[1].start_point_long,
                                        "end_point": rows[1].end_point,
                                        "end_point_lat": rows[1].end_point_lat,
                                        "end_point_long": rows[1].end_point_long,
                                        "start_date": rows[1].start_date,
                                        "start_time": rows[1].start_time,
                                        "seats": rows[1].seats,
                                        "seat_available": rows[1].seat_available,
                                        "route_lat_long": rows[1].route_lat_long,
                                        "created_dt": rows[1].created_dt,
                                        "vehicle_id": rows[1].vehicle_id,
                                        "make": rows[1].make,
                                        "model": rows[1].model
                                    },
                                    "findRide": row2
                                }]
                            }
                        ]
                };
            }
            if (rows.length == 1) {
                /* data for the first ride.*/
                if (rows[0].seat_available == 0) {
                    var [row1, field1] = await conn.execute(`SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN users AS U ON U.uid=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id= ${req.driver_id} AND user_type=${req.user_type}) AND FR.is_deleted="0" AND U.is_deleted="0" AND FR.start_date='${req.start_date}' AND FR.is_booked = "1" 
                    UNION

                    SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name  FROM find_rides AS FR INNER JOIN parents AS U ON U.parent_user_id=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id=driver_id= ${req.driver_id} AND user_type=${req.user_type}) AND FR.is_deleted="0" AND U.is_deleted="0" AND FR.start_date='${req.start_date}' AND FR.is_booked = "1" 
                    
                    `);
                }
                else {

                    var ti = new Date(2001, 1, 1, rows[0].start_time.split(":")[0], rows[0].start_time.split(":")[1]);
                    ti = ("0" + ti.getHours(ti.setHours(ti.getHours() + 4))).slice(-2) + ":" + rows[0].start_time.split(":")[1] + ":" + rows[0].start_time.split(":")[2];
                    var [row1, field1] = await conn.execute(`SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name  FROM find_rides AS FR INNER JOIN users AS U ON U.uid=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE 
                        driver_id= ${req.driver_id} AND user_type= ${req.user_type}) AND FR.is_deleted="0"  AND U.is_deleted="0" AND FR.start_date= 
                        '${req.start_date}' AND FR.start_time >='${rows[0].start_time}' AND FR.start_time <='${ti}' AND FR.seats <= ${rows[0].seat_available}
                    UNION
                    SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN parents AS U ON U.parent_user_id =FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id=${req.driver_id} AND 
                    user_type=${req.user_type}) AND FR.is_deleted="0"  AND U.is_deleted="0" AND FR.start_date='${req.start_date}' AND FR.start_time >='${rows[0].start_time}' AND FR.start_time <='${ti}' AND FR.seats <= ${rows[0].seat_available}`);
                    //console.log("++++",query);
                }
                conn.release();
                return {
                    offered: 1, "data":
                        [
                            {
                                "firstRide": [{
                                    "offerRide":
                                    {
                                        "id": rows[0].id,
                                        "start_point": rows[0].start_point,
                                        "start_point_lat": rows[0].start_point_lat,
                                        "start_point_long": rows[0].start_point_long,
                                        "end_point": rows[0].end_point,
                                        "end_point_lat": rows[0].end_point_lat,
                                        "end_point_long": rows[0].end_point_long,
                                        "start_date": rows[0].start_date,
                                        "start_time": rows[0].start_time,
                                        "seats": rows[0].seats,
                                        "seat_available": rows[0].seat_available,
                                        "route_lat_long": rows[0].route_lat_long,
                                        "created_dt": rows[0].created_dt,
                                        "vehicle_id": rows[0].vehicle_id,
                                        "make": rows[0].make,
                                        "model": rows[0].model
                                    },
                                    "findRide": row1
                                }]
                            }
                        ]
                };
            }

            // const query = connection.format('SELECT FR.id, FR.uid, FR.start_point_lat, FR.start_point_long, FR.start_point, FR.end_point, FR.end_point_lat, FR.end_point_long, FR.start_date, FR.start_time, FR.seats, FR.special_request, FR.is_booked, U.first_name, U.last_name, U.gender FROM `find_rides` AS FR INNER JOIN users AS U ON U.uid=FR.uid WHERE FR.id NOT IN (SELECT findRide_id FROM cancel_find_ride WHERE driver_id=?) AND FR.is_deleted="0" AND U.is_deleted="0" AND FR.start_date=?', [req.driver_id, req.start_date]);
            // console.log(query);

        }
        else {
            return { offered: 0, data: [], offerData: [] };
        }
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/* Accept ride request by driver  */

module.exports.acceptRide = async (req) => {
    try {
        /* Check if ride is already booked. */
        var conn = await connection.getConnection();
        const [rows, fields] = await conn.execute('SELECT * FROM find_rides WHERE is_booked !="1" AND id=? AND uid = ?', [req.ride_id, req.uid]);
        if (rows.length > 0) {
            let seatsRequested = rows[0].seats;
            let result = await conn.execute('UPDATE find_rides SET is_booked= "1", driver_user_type="2", driver_id=? WHERE uid =? AND id=? ', [req.driver_id, req.uid, req.ride_id]);
            let result1 = await conn.execute(`UPDATE offer_rides SET seat_available = seat_available-${seatsRequested} WHERE id=? `, [req.offer_ride_id]);  
            conn.release();
            return "Ride Accept successfully";
        } else {
            conn.release();
            return "Already booked";
        }
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/* Cancel ride request by driver */

module.exports.cancelFindRide = async (req) => {
    try {
        var conn = await connection.getConnection();
        const [rows, fields] = await conn.execute('SELECT * FROM find_rides WHERE id=? ', [req.findRide_id]);
        if(rows.length > 0) {
            const sql = conn.format('insert into `cancel_find_ride` (`findRide_id`,`driver_id`,`user_type`) values(?,?,?)', [req.findRide_id, req.driver_id, req.user_type]);
            let [ResultSetHeader] = await conn.execute(sql);
            conn.release();
            return "Added successfully ";
        } else {
            conn.release();
            return { statusCode: 500, message: `Record doesn't match with our datbase.`} ;
        }
    } catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }

}


function mailfunction(from, to, subject, first_name,url) {

    const text = `<table cellpadding="0" cellspacing="0" style="font-family:'Labtop',sans-serif;font-size:14px;border-radius:3px;background:#fff;margin:0;padding:0;border:1px solid #e9e9e9;margin:0 auto;max-width:700px" width="100%">
    <div style="padding-left:300px;">
    <img src="http://64.150.183.17:1009/logo.png" style="width:120px;margin-top:20px;">
    </div>
        <tbody>
            <tr style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0;background:white">
                <td colspan="3" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:20px;border-top:10px solid #ffffff" valign="top">
                <table cellpadding="0" cellspacing="0" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0" width="100%">
                    <tbody>
                        <tr>
                            <td width="15%"></td>
                            <td style="font-weight:300;vertical-align:top;padding-bottom:25px;color:dimgray;width:70%;padding:10px;text-align:left" valign="top">
                            <p style="font-size:16px">Hello ${first_name},</p>
    
                            <p style="font-size:16px">Thanks for Joining Brentwood.</p>
    
                            <p style="font-size:16px">To complete your Brentwood registration we need you to confirm your email address.</p>
    
    <p style="font-size:16px">Click the button below to.</p>
                            <p style="font-size:16px"><a href="${url}"><button style="background-color: blue;border-radius: 14px;color:#fff;height:40px" type="button">Verify Email</button></a></p>
    
                            <p style="font-size:16px">All the best,</p>
    
                            <p style="font-size:16px">Brentwood Team</p>
                            </td>
                            <td width="15%"></td>
                        </tr>
                    </tbody>
                </table>
                </td>
            </tr>
        </tbody>
    </table>`;
    var transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        requireTLS: true,
        auth: {
            user: "ashwini.singh@mobileprogramming.com",
            pass: "Reecha@1985"
        }
    });

    const mailOptions = {
        from: from, // sender address
        to: to, // list of receivers
        subject: subject, // Subject line
        html: text// plain text body
    };

    transporter.sendMail(mailOptions, function (err, info) {
        if (err)
            console.log(err)
        else
            console.log(info);
    });

}

/* mail funtion for user below 13 */

function mailfunctionBelowThirteen(from, to, subject, first_name,url) {

    const text = `<table cellpadding="0" cellspacing="0" style="font-family:'Labtop',sans-serif;font-size:14px;border-radius:3px;background:#fff;margin:0;padding:0;border:1px solid #e9e9e9;margin:0 auto;max-width:700px" width="100%">
    <div style="padding-left:300px;">
    <img src="http://64.150.183.17:1013/brentwood-logo.png" style="width:120px;margin-top:20px;">
    </div>
        <tbody>
            <tr style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0;background:white">
                <td colspan="3" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:20px;border-top:10px solid #ffffff" valign="top">
                <table cellpadding="0" cellspacing="0" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0" width="100%">
                    <tbody>
                        <tr>
                            <td width="15%"></td>
                            <td style="font-weight:300;vertical-align:top;padding-bottom:25px;color:dimgray;width:70%;padding:10px;text-align:left" valign="top">
                            <p style="font-size:16px">Hello ${first_name},</p>
    
                            <p style="font-size:16px">Your child has registered on the Brentwood application.</p>
    
                            <p style="font-size:16px">Please click on “Verify email” to give you approval to them to use the application”</p>
    
                            <p style="font-size:16px"><a href="${url}"><button style="background-color: blue;border-radius: 14px;color:#fff;height:40px" type="button">Verify Email</button></a></p>
    
                            <p style="font-size:16px">All the best,</p>
    
                            <p style="font-size:16px">Brentwood Team</p>
                            </td>
                            <td width="15%"></td>
                        </tr>
                    </tbody>
                </table>
                </td>
            </tr>
        </tbody>
    </table>`;
    var transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 587,
        secure: false,
        requireTLS: true,
        auth: {
            user: "ashwini.singh@mobileprogramming.com",
            pass: "Reecha@1985"
        }
    });

    const mailOptions = {
        from: from, // sender address
        to: to, // list of receivers
        subject: subject, // Subject line
        html: text// plain text body
    };

    transporter.sendMail(mailOptions, function (err, info) {
        if (err)
            console.log(err)
        else
            console.log(info);
    });

}

/* update user or parent table verified flag */

module.exports.updateVerifyFlag = async (email, user_type) => {
    var conn = await connection.getConnection();
    if (user_type == 1) {
        let result = await conn.execute(`UPDATE users SET verified = '1',is_registered = '1' WHERE user_email=? `, [email]);
    }
    else {
        let result = await conn.execute(`UPDATE parents SET verified = '1' WHERE email=? `, [email]);
    }
    conn.release();
}


/* login method */

module.exports.login = async (email, password) => {
    var conn = await connection.getConnection();
    const [rows, fields] = await conn.execute(`select uid,phone,first_name,last_name,profile_pic,DATE_FORMAT(dob, '%Y-%m-%d') AS dob,parent1_user_id,user_email,user_pass,verified from users where user_email = ? `, [email]);
    const studentData = rows;
    if (studentData.length > 0) {
        //get parent address
        const [rows, fields] = await conn.execute(`select address from parents where parent_user_id = ? `, [studentData[0].parent1_user_id]);
        //check user is verified ??
        if (studentData[0].verified == '0') {
            conn.release();
            return {
                message: "user not verified !!!",
                loggedin: 0

            };
        }
        const isEqual = await bcrypt.compare(password, studentData[0].user_pass);
        if (!isEqual) {
            return {
                message: "Please enter correct password.",
                loggedin: 0

            };
        }
        else {
            //genrate json web token
            const token = jwt.sign({
                email: email,
                user_type: 1
            }, "ashsupersecrate", {
                expiresIn: "7d"
            });

            return {
                message: "loggedin!!!",
                token: token,
                userId: studentData[0].uid,
                first_name: studentData[0].first_name,
                last_name: studentData[0].last_name,
                address: rows[0].address,
                email: studentData[0].user_email,
                phone: studentData[0].phone,
                profile_pic : studentData[0].profile_pic,
                loggedin: 1,
                user_type: 1,
                dob: studentData[0].dob
            };
        }
    }
    else {
        // find user in parent table
        const [rows, fields] = await conn.execute(`select parent_user_id,email,phone,password,verified,first_name,last_name,profile_pic,address from parents where email = ? `, [email]);
        if (rows.length > 0) {
            //check user is verified ??
            if (rows[0].verified == '0') {
                conn.release();
                return {
                    message: "user not verified !!!",
                    loggedin: 0

                };

            }

            const isEqual = await bcrypt.compare(password, rows[0].password);
            if (!isEqual) {
                return {
                    message: "Please enter correct password.",
                    loggedin: 0

                };
            }
            else {
                //genrate json web token
                const token = jwt.sign({
                    email: email,
                    user_type: 2
                }, "ashsupersecrate", {
                    expiresIn: "7d"
                });

                return {
                    message: "loggedin!!!",
                    token: token,
                    userId: rows[0].parent_user_id,
                    first_name: rows[0].first_name,
                    last_name: rows[0].last_name,
                    address: rows[0].address,
                    email: rows[0].email,
                    phone: rows[0].phone,
                    profile_pic : rows[0].profile_pic,
                    loggedin: 1,
                    user_type: 2,
                    dob : ''
                };
            }
        }
    }
    return {
        message: "Please enter correct email id.",
        loggedin: 0

    };
}

/* profile update */

module.exports.profileUpdate = async (uid, phone_no, profile_pic, user_type) => {
    try {
       //if profile pic is set
       if(profile_pic != null)
       {
        if (user_type == 1) {
            let result = await connection.execute(`UPDATE users SET profile_pic = '${profile_pic}',phone = '${phone_no}' WHERE uid=? `, [uid]);
            const rows = await getUserByUid(uid,user_type);
            const profile = rows[0].profile_pic;
            return { status: 1, message: "profile updated successfully" ,profile : profile }
        }
        else {
            let result = await connection.execute(`UPDATE parents SET profile_pic = '${profile_pic}',phone = '${phone_no}' WHERE parent_user_id =? `, [uid]);
            const rows = await getUserByUid(uid,user_type);
            console.log(rows);
            const profile = rows[0].profile_pic;
            console.log(profile);
            return { status: 1, message: "profile updated successfully",profile : profile }
        }  
       }
       else
       {
        if (user_type == 1) {
            let result = await connection.execute(`UPDATE users SET phone = '${phone_no}' WHERE uid=? `, [uid]);
            const rows = await getUserByUid(uid,user_type);
            const profile = rows[0].profile_pic;
            return { status: 1, message: "profile updated successfully" ,profile : profile}
        }
        else {
            let result = await connection.execute(`UPDATE parents SET phone = '${phone_no}' WHERE parent_user_id =? `, [uid]);
            const rows = await getUserByUid(uid,user_type);
            const profile = rows[0].profile_pic;
            return { status: 1, message: "profile updated successfully" ,profile : profile}
        }
       }
       
    }
    catch (error) {
        return { status: 0, message: error }
    }


}

/* method for signupBelowThirteen user */

module.exports.signupBelowThirteen = async (studetEmail, parentEmail) => {
    try {
        var conn = await connection.getConnection();
        let [rows, fields] = await conn.execute(`select parent1_user_id,parent2_user_id from users where user_email = ? `, [studetEmail]);
        let [rows1] = await conn.execute(`select * from parents where email = ? AND parent_user_id IN(${rows[0].parent1_user_id},${rows[0].parent2_user_id}) `, [parentEmail]);
        if (rows1.length > 0) {
            console.log("inside");
            // we can set expiration time using sync
            const token = jwt.sign({ email: studetEmail, user_type: 1 }, 'brentwoodsecreatekey', { expiresIn: "7d" });
            const subject = "Please confirm Signup of your child in brentwood carpool app ";
            const URL = "http://64.150.183.17:1013/auth/verify?token=" + token;
            const text = "Hello,<br> Please Click on the link to verify your email.<br><a href=" + URL + ">Click here to verify</a>";
            mailfunctionBelowThirteen('Brentwood Admin<admin@brentwood.com>', parentEmail, subject, rows1[0].first_name,URL);
            conn.release();
            return true;
        }
        conn.release();
        return false;
    }
    catch (error) {
        conn.release();
        return { status: 0, message: "something wrong!!!" }
    }
}


module.exports.scheduleRide = async (req) => {
    try {
        var conn = await connection.getConnection();
        if (req.ride_type == "offer") {
            if(req.user_type==1) {
                [rows, fields] = await conn.execute(`SELECT DATE_FORMAT(OFR.start_date, '%Y-%m-%d') as start_date, U.first_name, U.last_name FROM offer_rides AS OFR INNER JOIN users AS U ON U.uid = OFR.uid WHERE OFR.is_deleted ='0' AND OFR.start_date >= DATE(NOW()) AND OFR.uid =? `, [req.driver_id]);
            } else {
                [rows, fields] = await conn.execute(`SELECT DATE_FORMAT(OFR.start_date, '%Y-%m-%d') as start_date, P.first_name, P.last_name FROM offer_rides AS OFR INNER JOIN parents AS P ON P.parent_user_id = OFR.uid WHERE OFR.is_deleted ='0' AND OFR.start_date >= DATE(NOW()) AND OFR.uid =? `, [req.driver_id]);
            }
            
        } else if (req.ride_type == "request") {
            if(req.user_type==1) {
                [rows, fields] = await conn.execute(`SELECT DATE_FORMAT(FR.start_date,'%Y-%m-%d') as start_date, U.first_name, U.last_name FROM find_rides AS FR INNER JOIN users AS U ON U.uid = FR.uid WHERE FR.is_deleted ='0' AND FR.start_date >= DATE(NOW()) AND FR.uid =? `, [req.driver_id]);
            } else{
                [rows, fields] = await conn.execute(`SELECT DATE_FORMAT(FR.start_date,'%Y-%m-%d') as start_date, P.first_name, P.last_name FROM find_rides AS FR INNER JOIN parents AS P ON P.parent_user_id = FR.uid WHERE FR.is_deleted ='0' AND FR.start_date >= DATE(NOW()) AND FR.uid =? `, [req.driver_id]);
            }
            
        } else {
            return "Invalid ride type.";
        }
        if (rows.length > 0) {
            conn.release();
            return rows;
        } else {
            conn.release();
            return "No upcomming ride schedule.";
        }
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

/*method for geting user by uid and user type */

async function  getUserByUid(uid,user_type)
{
    if(user_type == 1)
    {
        const [rows, fields] = await connection.execute('SELECT * FROM `users` WHERE `uid` = ?', [uid]);
        return rows;

    }
    else
    {
        const [rows, fields] = await connection.execute('SELECT * FROM `parents` WHERE `parent_user_id` = ?', [uid]);
        return rows; 
    }

}

/* Udpate user picked status and time */

module.exports.pickUser = async (req) => {
    try {
        var conn = await connection.getConnection();
        var result = await conn.execute(`UPDATE find_rides SET is_picked='1', picked_dt=now() WHERE is_deleted ='0' AND id=? AND uid=? AND user_type=? AND driver_id=? AND driver_user_type=?`, [req.ride_id, req.uid, req.user_type, req.driver_id, req.driver_type]);
        conn.release();
        if(result[0].changedRows == 1) {
            return "User picked successfully." ;
        } else {
            return { statusCode: 500, message: `Record doesn't match with our datbase.`} ;     
        }
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}


module.exports.dropUser = async (req) => {
    try {
        var conn = await connection.getConnection();
        var result = await connection.execute(`UPDATE find_rides SET is_drop='1', drop_dt=now() WHERE is_deleted ='0' AND id=? AND uid=? AND user_type=? AND driver_id=? AND driver_user_type=?`, [req.ride_id, req.uid, req.user_type, req.driver_id, req.driver_type]);
        conn.release();
        if(result[0].changedRows == 1) {
            return "User droped successfully." ;
        } else {
            return { statusCode: 500, message: `Record doesn't match with our datbase.`} ;     
        }
    }
    catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}

module.exports.addDriver = async (req) => {
    try {
        var conn = await connection.getConnection();
        const [rows, fields] = await connection.execute('SELECT * FROM parents WHERE parent_user_id=? ', [req.uid]);
        if(rows.length > 0) {
            const sql = connection.format('insert into `parents` (`first_name`,`last_name`,`email`,`phone`,`added_by`,`user_type`) values(?,?,?,?,?,?)', [req.first_name, req.last_name, req.email, req.phone, req.uid,'3']);
            let [ResultSetHeader] = await connection.execute(sql);
            conn.release();
            return "Added successfully ";
        } else {
            conn.release();
            return { statusCode: 500, message: `Record doesn't match with our datbase.`} ;
        }
    } catch (error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        return error;
    }
}