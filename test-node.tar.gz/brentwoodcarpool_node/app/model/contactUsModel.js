'use strict';
const connection = require('../../db.js');

/* Submit user query to admin. */

module.exports.contactUs = async (req) => {
    var conn = await connection.getConnection();
    let [ResultSetHeader] = await connection.execute('insert into `contact_us` (`name`,`emailAddress`,`massage`) values(?,?,?)', [req.name, req.emailAddress, req.massage]);
    conn.release();
    if (ResultSetHeader.insertId) {
        return 1;
    }
    else {
        return 0;
    }

}

module.exports.feedback = async (req) => {
    var conn = await connection.getConnection();
    let [ResultSetHeader] = await connection.execute('insert into `feedback` (`driver_id`,`uid`,`user_type`,`comment`) values(?,?,?,?)', [req.driver_id, req.uid, req.user_type, req.comment]);
    conn.release();
    if (ResultSetHeader.insertId) {
        return 1;
    }
    else {
        return 0;
    }

}

