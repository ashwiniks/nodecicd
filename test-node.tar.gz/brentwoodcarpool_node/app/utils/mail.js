
const nodemailer = require('nodemailer');

module.exports.mailfunction = async (from, to, subject, message) => {
  try {

  var transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false,
    requireTLS: true,
    auth: {
        user: "ashwini.singh@mobileprogramming.com",
        pass: "Reecha@1985"
    }
});

const mailOptions = {
    from: from, // sender address
    to: to, // list of receivers
    subject: subject, // Subject line
    html: message// plain text body
};

let info = await  transporter.sendMail(mailOptions);
 return { status: 1, message: "mail  send" }
      
  } catch (error) {
    return { status: 0, message: "mail not send" };
    console.log(err);
  }
  

}