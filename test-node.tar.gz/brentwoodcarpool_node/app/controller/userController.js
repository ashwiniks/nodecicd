
var User = require('../model/userModel.js');

const { body,validationResult } = require('express-validator/check');

exports.validate = (method) => {

    switch (method) {    
        case 'request_ride': {
          return [
            body('uid').not().isEmpty().withMessage("uid is required").isInt().withMessage("Value must be integer."),
            body('start_point', "start_point is required").not().isEmpty(),
            body('start_point_lat', "start_point_lat is required").not().isEmpty(),
            body('start_point_long', "start_point_long is required").not().isEmpty(),
            body('end_point', "end_point is required").not().isEmpty(),
            body('end_point_lat', "end_point_lat is required").not().isEmpty(),
            body('end_point_long', "end_point_long is required").not().isEmpty(),
            body('start_date').not().isEmpty().withMessage("Start date is required.").isISO8601().withMessage("Valid Start date is required"),
            body('start_time', "Valid start_time is required").not().isEmpty(),
            //body('seats',{isEmpty : 'seats is required',isInt : 'Seats can be between 1 and 4'} ).isInt({ min: 1, max: 4 }).isEmpty(),
            body('seats').not().isEmpty().isInt({ min: 1, max: 4 }).withMessage('Seats can be between 1 and 4'),
            body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2')
            
          ]
        }
        case 'offer_ride': {
          return [
            body('uid', "uid is required").isInt().not().isEmpty(),
            body('vehicle_id', "vehicle_id is required").isInt().not().isEmpty(),
            body('start_point', "start_point is required").not().isEmpty(),
            body('start_point_lat', "start_point_lat is required").not().isEmpty(),
            body('start_point_long', "start_point_long is required").not().isEmpty(),
            body('end_point', "end_point is required").not().isEmpty(),
            body('end_point_lat', "end_point_lat is required").not().isEmpty(),
            body('end_point_long', "end_point_long is required").not().isEmpty(),
            body('start_date', "Valid start_date is required").isISO8601().not().isEmpty(),
            body('start_time', "Valid start_time is required").not().isEmpty(),
            //body('seats',{isEmpty : 'seats is required',isInt : 'Seats can be between 1 and 4'} ).isInt({ min: 1, max: 4 }).isEmpty(),
            body('seats').not().isEmpty().isInt({ min: 1, max: 4 }).withMessage('Seats can be between 1 and 4'),
            body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2'),
            body('route_lat_long',"route_lat_long is required").not().isEmpty(),
          ]
        }
        case 'cancel_ride': {
          return [
            body('uid', "uid is required").isInt().not().isEmpty(),
            body('ride_id', "ride_id is required").isInt().not().isEmpty(),
            body('request_type').not().isEmpty().withMessage("request_type is required").isIn(["request","offer"]).withMessage("Invalid request type."),
            body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2'),
          ]
        }
        case 'list_request_ride': {
          return [
            body('uid', "uid is required").isInt().not().isEmpty(),
            body('request_type', "request_type is required").isInt().not().isEmpty(),
            body('start_date', "start_date is required").isISO8601().not().isEmpty()
          ]
        }
        case 'list_offer_ride': {
          return [
            body('uid', "uid is required").isInt().not().isEmpty(),
            body('request_type', "request_type is required").isInt().not().isEmpty()
          ]
        }
        case 'new_request': {
          return [
            body('start_date', "Valid start_date is required").isISO8601().not().isEmpty(),
            //body('start_time', "Valid start_time is required").not().isEmpty(),
            body('driver_id', "driver_id is required").isInt().not().isEmpty(),
            body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2')
          ]
        }
        case 'accept_ride': {
          return [
            body('ride_id', "ride_id is required").isInt().not().isEmpty(),
            body('uid', "uid is required").isInt().not().isEmpty(),
            body('driver_id', "driver_id is required").isInt().not().isEmpty(),
          ]
        }
        case 'cancel_find_ride': {
            return [
              body('findRide_id', "findRide id is required").isInt().not().isEmpty(),
              body('driver_id', "driver id is required").isInt().not().isEmpty(),
              body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2')
            ]
        }
        case 'schedule_rides': {
            return [
              body('ride_type', "ride_type id is required").not().isEmpty(),
              body('driver_id', "driver id is required").isInt().not().isEmpty(),
              body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2')
            ]
        }
        case 'pick_user': {
            return [
              body('ride_id', "ride_type id is required").isInt().not().isEmpty(),
              body('uid', "uid is required").isInt().not().isEmpty(),
              body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2'),
              body('driver_id', "driver id is required").isInt().not().isEmpty(),
              body('driver_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2')
            ]
        }
        case 'drop_user': {
            return [
              body('ride_id', "ride_type id is required").isInt().not().isEmpty(),
              body('uid', "uid is required").isInt().not().isEmpty(),
              body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2'),
              body('driver_id', "driver id is required").isInt().not().isEmpty(),
              body('driver_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2')
            ]
        }
        case 'add_driver': {
            return [
              body('uid', "uid is required").isInt().not().isEmpty(),
              body('first_name','first_name is required').not().isEmpty(),
              body('last_name','last_name is required').not().isEmpty(),
              body('email','email is required').not().isEmpty(),
              body('phone','phone is required').not().isEmpty()
            ]
        }
      }
    };

    const signupFailures = ({location, msg, param, value, nestedErrors}) => {
        return {
            param: param,
            message: msg,
            nestedErrors: nestedErrors
        }
    };

module.exports.request_ride = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const user = await User.requestRide(req.body);
        if(user.statusCode == "500") {
            const error = new Error(user.message);
            res.statusCode = 400;
            throw error;
        }
        else if(user.statusCode == "422")
        {
            res.status(422).json({error: 1, status:0, message: user.message });  
        }
        else {
            res.status(200).json({error: 0, status:1, rid : user, message: "Ride created successfully." });  
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

module.exports.offer_ride = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const user = await User.offerRide(req.body);
        if(user.statusCode == "500") {
            const error = new Error(user.message);
            res.statusCode = 400;
            throw error;
        } 
        else if(user.statusCode == "422")
        {
            res.status(422).json({error: 1, status:0, message: user.message });  
        }
        
        else {
            res.status(200).json({error: 0, status:1, rid : user, message: "Offer ride created successfully." });  
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

module.exports.cancel_ride = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const user = await User.cancelRide(req.body);
        if(user.statusCode == "500") {
            const error = new Error(user.message);
            res.statusCode = 400;
            throw error;
        } else {
            res.status(200).json({error: 0, status:1, message: "Ride Cancelled." });  
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

module.exports.list_request_ride = async (req, res, next) => {
    try {
        const errors = validationResult(req.query).formatWith(signupFailures); 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const requestList = await User.listRequestRide(req.query);
        console.log(requestList);
        if(requestList.statusCode == "500") {
            const error = new Error(requestList.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: requestList , date: requestList.start_date});
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

module.exports.list_offer_ride = async (req, res, next) => {
    try {
        const errors = validationResult(req.query).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const offerList = await User.listOfferRide(req.query);
        if(offerList.statusCode == "500") {
            const error = new Error(offerList.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: offerList });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

module.exports.new_request = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const response = await User.newRequest(req.body);
        console.log(response);
        if(response.statusCode == "500") {
            const error = new Error(response.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, offered: response.offered,data: response.data,offerData:response.offerData });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

module.exports.accept_ride = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const response = await User.acceptRide(req.body);
        if(response.statusCode == "500") {
            const error = new Error(response.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: response });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};


module.exports.cancel_find_ride = async (req,res,next)=> {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const response = await User.cancelFindRide(req.body);
        if(response.statusCode == "500") {
            const error = new Error(response.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: response });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

module.exports.schedule_rides = async (req,res,next)=> {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const response = await User.scheduleRide(req.body);
        if(response.statusCode == "500") {
            const error = new Error(response.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: response });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

module.exports.pick_user = async (req,res,next)=> {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const response = await User.pickUser(req.body);
        if(response.statusCode == "500") {
            const error = new Error(response.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: response });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

module.exports.drop_user = async (req,res,next)=> {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const response = await User.dropUser(req.body);
        if(response.statusCode == "500") {
            const error = new Error(response.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: response });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

module.exports.add_driver = async (req,res,next)=> {
    try {
        const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const response = await User.addDriver(req.body);
        if(response.statusCode == "500") {
            const error = new Error(response.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: response });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}

