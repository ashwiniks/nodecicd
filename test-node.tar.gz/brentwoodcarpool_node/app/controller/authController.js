var User = require('../model/userModel.js');
const connection = require('../../db.js');
const jwt = require('jsonwebtoken');
const fs= require('fs');
//const uploader = require('base64-image-upload');
const { body, validationResult } = require('express-validator/check');
const multer = require('multer');
const path = require('path');


var storage =   multer.diskStorage({
  destination: function (req, file, callback) {
    //callback(null, './pic');
    callback(null, './pic');
  },
  filename: function (req, file, callback) {
    //callback(null, file.fieldname + '-' + Date.now());
    callback(null, new Date().toISOString().replace(/[-T:\.Z]/g, "") + file.originalname) ;
  }
});

var upload = multer({ storage : storage}).single('profile_pic');


exports.validate = (method) => {

    switch (method) {
    
        case 'signup': {
          return [
            //body('firstname', "firstname is required").not().isEmpty(),
            //body('lastname', "lastname is required").not().isEmpty(),
            body('emailAddress', "valid emailAddress is required").not().isEmpty().isEmail(),
            body('user_pass', "password is required").not().isEmpty(),
            body('phone', "phone is required").not().isEmpty(),
            body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2'),
            body('dob', "Valid dob is required").isISO8601().not().isEmpty()
            
          ]
        }
        case 'profileupdate': {
            return [
              /*body('profile_pic', "profile_pic is required").not().isEmpty(),
              body('uid', "uid is required").not().isEmpty(),
              body('phone_no', "phone is required").not().isEmpty(),
              body('user_type').isInt({ min: 1, max: 2 }).withMessage('user type can be 1 or 2')*/
              
            ]
          }

        case 'signin': {
            return [
    
              body('emailAddress', "valid emailAddress is required").not().isEmpty().isEmail(),
              body('user_pass', "password is required").not().isEmpty(),
              
            ]
          }

          case 'signupbelowthirteen': {
            return [
    
              body('studetEmail', "valid emailAddress is required").not().isEmpty().isEmail(),
              body('parentEmail', "valid emailAddress is required").not().isEmpty().isEmail(),
              
            ]
          }
       
      }
    };

    const signupFailures = ({location, msg, param, value, nestedErrors}) => {
        return {
            param: param,
            message: msg,
            nestedErrors: nestedErrors
        }
    };

module.exports.signUp = async (req, res, next) => {


    // check if user already exist in school database ?
    try {
        const errors = validationResult(req).formatWith(signupFailures);
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }

        const isUser = await User.checkUser(req.body);
        if (!isUser.status) {
            const error = new Error(isUser.message);
            res.statusCode = 400;
            throw error;
        }
        else {
            //register the user
            const user = await User.signUp(req.body);
            console.log(user);
            if (!user) {
                const error = new Error('user already registerd !!');
                res.statusCode = 400;
                throw error;
            }
            else {
                res.status(200).json({ message: "user registerd succesfully" });
            }
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
}


module.exports.verifyToken = async (req,res,next)=>{
try{
    const token = req.query.token;
    const decodeToken = await jwt.verify(token,'brentwoodsecreatekey');
   // console.log(decodeToken.data);
    const result = User.updateVerifyFlag(decodeToken.email,decodeToken.user_type);
    res.send(`<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        .email-txt{
            font-family: Arial, Helvetica, sans-serif;
            font-size: 16px;
        }

    </style>
</head>
<body>
    <div class="container">
        <div class="col-sm-12">
            <div class="row">
                <div class="col-sm-12">
                        <img src="http://64.150.183.17:1013/brentwood-logo.png" style="width:200px">
                </div>
                <div class="col-sm-12 email-txt">
                    <br><br>
                        
                        
                            Thank you for confirming your email, your registration is now complete. 
                        
                        <br><br>
                </div>
                <div class="col-sm-12 email-txt">
                        Regards,<br>
                        Brentwood Team
                </div>
            </div>
        </div>
    </div>

<div id="selection_bubble" style="position:absolute;	visibility:hidden; padding:15px; color:#333; background-color: white; border: 5px solid black; border-radius:10px; width:300px; z-index:10000"></div></body></html>`);
}
catch(err)
{
console.log(err);
res.json({
    confirmation: 'fail',
    message: 'Invalid Token'
});
}


}

/** method for signin */

module.exports.signIn = async(req,res,next)=>{
    
    const errors = validationResult(req).formatWith(signupFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }

    const  result = await User.login(req.body.emailAddress,req.body.user_pass)
    console.log(result);
    if(result.loggedin == 1)
    {
     res.status(200).json({status:1,"message":result.message,token:result.token,userId:result.userId,first_name:result.first_name,last_name:result.last_name,address:result.address,email:result.email,phone:result.phone,profile_pic:result.profile_pic,user_type:result.user_type,dob:result.dob});
    }
    else {
        res.status(200).json({status: 0 ,"message":result.message});
    }
}


/* update profile */

module.exports.profileUpdate = async (req, res, next) => {
    try{
        var conn = await connection.getConnection();
        var tmp = 0;
        upload(req,res,function(err) {
            if(err) {
                return res.end("Error uploading file.");
            } else {
                if (typeof req.file !== 'undefined') {
                    if (req.body.user_type == 1) {
                        var sql = `UPDATE users SET profile_pic = '${req.file.filename}', phone = '${req.body.phone_no}' WHERE uid='${req.body.uid}'`;
                        conn.query(sql, function (err, result) {
                            if (err) throw err;
                        });
                        conn.release();
                        return res.status(200).json({status: 1 ,"message":"Record updated succesfully.","phone":req.body.phone_no,"image":"http://64.150.183.17:1013/"+req.file.filename});
                    } else {
                        var sql = `UPDATE parents SET profile_pic = '${req.file.filename}', phone = '${req.body.phone_no}' WHERE parent_user_id='${req.body.uid}'`;
                        conn.query(sql, function (err, result) {
                            if (err) throw err;
                        });
                        conn.release();
                        return res.status(200).json({status: 1 ,"message":"Record updated succesfully.","phone":req.body.phone_no,"image":"http://64.150.183.17:1013/"+req.file.filename});
                    }
                } else {
                   if (req.body.user_type == 1) {
                        var sql = `UPDATE users SET phone = '${req.body.phone_no}' WHERE uid='${req.body.uid}'`;
                        conn.query(sql, function (err, result) {
                            if (err) throw err;
                        });
                        conn.release();
                        return res.status(200).json({status: 1 ,"message":"Record updated succesfully.","phone":req.body.phone_no});
                    } else {
                        var sql = `UPDATE parents SET phone = '${req.body.phone_no}' WHERE parent_user_id='${req.body.uid}'`;
                        conn.query(sql, function (err, result) {
                            if (err) throw err;
                        });
                        conn.release();
                        return res.status(200).json({status: 1 ,"message":"Record updated succesfully.","phone":req.body.phone_no});
                    } 
                }
            }
            //res.end("File is uploaded");
        });
    } catch(error) {
        conn.release();
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
   


}
/* method for register below 13 student */

module.exports.signupBelowThirteen = async (req,res,next)=>{

    const errors = validationResult(req).formatWith(signupFailures);
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }
    const result =  await User.signupBelowThirteen(req.body.studetEmail,req.body.parentEmail);
    console.log(result);
    if(result)
    {
        //res.status(200).json({ status: 1, message: "mail sent to your parent once verified you may logged in with your email and password" });
        res.status(200).json({ status: 1, message: "A verification email has been sent to your parent. Once they approve, you can login on the application" });
    }
    else
    {
        res.status(200).json({ status: 0, message: "Email address does not match with our record." });

    }
   
}


/* method for clear login data "temproray method" */

module.exports.clearLoginData = async (req, res, next) => {
  
    if (req.body.user_type == 1) {
        let result = await connection.execute(`UPDATE users SET is_registered = '0',verified = '0' WHERE user_email=? `, [req.body.emailAddress]);
        res.status(200).json( { status: 1, message: "success" });

    }
    else {
        let result = await connection.execute(`UPDATE parents SET is_registered = '0',verified = '0' WHERE email=? `, [req.body.emailAddress]);
        res.status(200).json( { status: 1, message: "success" });
    }
}
