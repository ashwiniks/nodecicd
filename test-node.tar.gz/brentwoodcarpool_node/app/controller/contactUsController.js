
const ContactUs = require('../model/contactUsModel');

const { body, validationResult } = require('express-validator/check');

exports.validate = (method) => {

    switch (method) {
        case 'contact_us': {
            return [
                body('name', "name is required").not().isEmpty(),
                body('emailAddress', "Valid emailAddress is required").isEmail(),
                body('massage', "massage is required").not().isEmpty()
            ]
        }
        case 'feedback': {
            return [
                body('driver_id', "driver_id is required").isInt().not().isEmpty(),
                body('uid', "uid is required").isInt().not().isEmpty(),
                body('user_type', "user_type is required").isInt().not().isEmpty(),
                body('comment', "comment is required").not().isEmpty()
            ]
        }
    }
};

const validationFailures = ({ location, msg, param, value, nestedErrors }) => {
    return {
        param: param,
        message: msg,
        nestedErrors: nestedErrors
    }
};

/* method for add vehical */
exports.contact_us = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(validationFailures);
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const contact = await ContactUs.contactUs(req.body);
        if (contact) {
            return res.status(200).json({ error: 0, status: 1, message: "Request submitted successfully."});
        }
        else {
            const error = new Error("someting is wrong please try again !!!");
            res.statusCode = 400;
            throw error;
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

/* method for add vehical */
exports.feedback = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(validationFailures);
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const contact = await ContactUs.feedback(req.body);
        if (contact) {
            return res.status(200).json({ error: 0, status: 1, data: { message: "Feedback submitted successfully." } });
        }
        else {
            const error = new Error("someting is wrong please try again !!!");
            res.statusCode = 400;
            throw error;
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};



