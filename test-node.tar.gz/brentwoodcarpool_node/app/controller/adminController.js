var adminUser = require('../model/adminModel.js');
const mail = require('../utils/mail');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const { body, validationResult } = require('express-validator/check');
exports.validate = (method) => {

    switch (method) {

        case 'login': {
            return [

                body('emailAddress', "valid emailAddress is required").not().isEmpty().isEmail(),
                body('password', "password is required").not().isEmpty(),

            ]
        }

        case 'comment': {
            return [

                body('emailAddress', "valid emailAddress is required").not().isEmpty().isEmail(),
                body('password', "password is required").not().isEmpty(),

            ]
        }

    }
};

const signupFailures = ({ location, msg, param, value, nestedErrors }) => {
    return {
        param: param,
        message: msg,
        nestedErrors: nestedErrors
    }
};



module.exports.verifyToken = async (req, res, next) => {
    try {
        const token = req.query.token;
        const decodeToken = await jwt.verify(token, 'brentwoodsecreatekey');
        console.log(decodeToken.data);
        const result = User.updateVerifyFlag(decodeToken.email, decodeToken.user_type);
        res.send("<h1>success</h1>");
    }
    catch (err) {
        console.log(err);
        res.json({
            confirmation: 'fail',
            message: 'Invalid Token'
        });
    }


}

/** method for signin */

module.exports.signIn = async (req, res, next) => {

    const errors = validationResult(req).formatWith(signupFailures);;
    if (!errors.isEmpty()) {
        res.status(422).json({ errors: errors.array() });
        return;
    }

    const result = await adminUser.login(req.body.emailAddress, req.body.password)
    console.log(result);
    if (result.loggedin == 1) {
        res.status(200).json({ status: 1, "message": result.message, token: result.token, userId: result.userId, first_name: result.first_name, last_name: result.last_name });
    }
    else {
        res.status(200).json({ status: 0, "message": result.message });

    }

}

/* method for listing comment */

module.exports.appComment = async (req, res, next) => {
    const getcomment = await adminUser.getComment();
    console.log();
    if (getcomment.length > 0) {
        res.status(200).json({ status: 1, "data": getcomment.filter(x => !!x) });

    }
    else {

        res.status(200).json({ status: 0, "data": getcomment });

    }
}


/*** send comment email */

module.exports.sendEmail = async (req, res, next) => {
    const from = 'Brentwood Admin<admin@brentwood.com>';
    const to = req.body.parent_email;
    const subject = "feedback mail";
    const commented_user_first_name = req.body.commented_user_first_name;
    const commented_user_from_name = req.body.commented_user_from_name;
    const message = `<table cellpadding="0" cellspacing="0" style="font-family:'Labtop',sans-serif;font-size:14px;border-radius:3px;background:#fff;margin:0;padding:0;border:1px solid #e9e9e9;margin:0 auto;max-width:700px" width="100%">
<div style="padding-left:300px;">
<img src="http://64.150.183.17:1009/logo.png" style="width:120px;margin-top:20px;">
</div>
    <tbody>
        <tr style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0;background:white">
            <td colspan="3" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;vertical-align:top;margin:0;padding:20px;border-top:10px solid #ffffff" valign="top">
            <table cellpadding="0" cellspacing="0" style="font-family:'Helvetica Neue','Helvetica',Helvetica,Arial,sans-serif;font-size:14px;margin:0;padding:0" width="100%">
                <tbody>
                    <tr>
                        <td width="15%"></td>
                        <td style="font-weight:300;vertical-align:top;padding-bottom:25px;color:dimgray;width:70%;padding:10px;text-align:left" valign="top">
                        <p style="font-size:16px">Hello ${commented_user_first_name},</p>

                        <p style="font-size:16px">Thanks for Joining Brentwood.</p>

                        <p style="font-size:16px">To complete your Brentwood registration we need you to confirm your email address.</p>

<p style="font-size:16px">Click the button below to.</p>
                        <p style="font-size:16px"><a href=""><button style="background-color: blue;border-radius: 14px;color:#fff;height:40px" type="button">Verify Email</button></a></p>

                        <p style="font-size:16px">All the best,</p>

                        <p style="font-size:16px">Brentwood Team</p>
                        </td>
                        <td width="15%"></td>
</tr>
                </tbody>
            </table>
                                </td>
        </tr>
    </tbody>
</table>`;
    const result = await mail.mailfunction(from, to, subject, message);
    console.log(result);
    if (result.status == 1) {
        res.status(200).json({ status: 1, message: "mail send successfully!!" });
    }
    else {
        res.status(200).json({ status: 0, message: "someting wrong please try again!!" });
    }
}

/* method for block and unblock user */
module.exports.blockUser= async (req,res,next)=> {
const is_block = req.body.is_block;
const user_type = req.body.user_type;
const emailAddress = req.body.emailAddress;
const result = await adminUser.blockUnblock(is_block,user_type,emailAddress);
if(result)
{
    res.status(200).json({ status: 1, message: "user blocked successfully!!" });

}
else
{
    res.status(200).json({ status: 0, message: "something wrong" });

}


}

/** method for list of blocked user */

module.exports.blockedUsers = async (req,res,next)=>{
  const result = await adminUser.blockedUser();
  res.status(200).json({ status: 1, data:result });


  
}


/** method for list of pending users */

module.exports.pendingRequest = async (req,res,next)=>{

    const result = await adminUser.pendingRequest();
    res.status(200).json({ status: 1, data:result });

}

/** pendingRequestApproveReject 1= approve 2= reject*/

module.exports.pendingRequestApproveReject = async (req,res,next)=>{
const result = await adminUser.pendingRequestApproveReject(req.body.action,req.body.emailAddress,req.body.driver_first_name);
res.status(200).json({ status: 1, message:result.message });


}


/** method for list of pending users history */

module.exports.pendingRequestHistory = async (req,res,next)=>{

    const result = await adminUser.pendingRequestHistory();
    res.status(200).json({ status: 1, data:result });

}
