
const Vehicle = require('../model/vehicleModel');

const { body, validationResult } = require('express-validator/check');

exports.validate = (method) => {

    switch (method) {

        case 'get_vehicle': {
            return [
                body('uid', "uid is required").isInt().not().isEmpty(),
                body('user_type', "user_type is required").isInt().not().isEmpty()
            ]
        }
        case 'add_vehicle': {
            return [
                body('uid', "uid is required").isInt().not().isEmpty(),
                body('user_type', "user_type is required").isInt().not().isEmpty(),
                body('manufacturing_year', "manufacturing year is required").not().isEmpty(),
                body('make', "make is required").not().isEmpty(),
                body('model', "model is required").not().isEmpty(),
                body('license_no', "license no is required").not().isEmpty()
            ]
        }
        case 'update_vehicle': {
            return [
                body('uid', "uid is required").isInt().not().isEmpty(),
                body('manufacturing_year', "manufacturing year is required").not().isEmpty(),
                body('make', "make is required").not().isEmpty(),
                body('model', "model is required").not().isEmpty(),
                body('license_no', "license no is required").not().isEmpty()
            ]
        }
        case 'delete_vehicle': {
            return [
                body('uid', "uid is required").isInt().not().isEmpty(),
                body('user_type', "user_type is required").isInt().not().isEmpty(),
                body('vehicle_id', "vehicle_id is required").isInt().not().isEmpty()
            ]
        }
    }
};

const validationFailures = ({ location, msg, param, value, nestedErrors }) => {
    return {
        param: param,
        message: msg,
        nestedErrors: nestedErrors
    }
};


/*
method for get Vehicle
*/
exports.getVehicle = async (req, res, next) => {
    try {
        //let uid = req.query.uid;
        const vehicle = await Vehicle.getVehicle(req.query);
        //if no data found
        if (!vehicle) {
            return res.status(200).json({ error: 0, status: 1, data: { message: "no data found" } });
        }
        if (vehicle.statusCode == "500") {
            const error = new Error(vehicle.message);
            res.statusCode = 400;
            throw error;
        } else {
            return res.status(200).json({ error: 0, status: 1, data: vehicle });
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

/*
method for add Vehicle
*/
exports.addVehicle = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(validationFailures);
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const vehicle = await Vehicle.addVehicle(req.body);
        if (vehicle==1) {
            return res.status(200).json({ error: 0, status: 1, data: { message: "vehicle added successfully" } });
        } else if(vehicle == 2){ 
            return res.status(200).json({ error: 1, status: 1, data: { message: "Under 18 user can not add vehicle." } });
        }
        else {
            const error = new Error("someting is wrong please try again !!!");
            res.statusCode = 400;
            throw error;
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};


/*
method for update Vehicle
*/
exports.updateVehicle = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(validationFailures);
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const id = req.params.id;
        const vehicle = await Vehicle.getVehicleById(id);
        if (!vehicle) {
            const error = new Error("vehicle  with this id not found ");
            res.statusCode = 400;
            throw error;
        }
        else {
            const vehicle = await Vehicle.updateVehicle(req.body, id);
            if (vehicle) {
                return res.status(200).json({ error: 0, status: 1, data: { message: "vehicle updated successfully" } });
            }
            else {
                const error = new Error("someting is wrong please try again !!!");
                res.statusCode = 400;
                throw error;
            }
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};

/* Delete Vehicle by user and vehicle ID */
module.exports.delete_vehicle = async (req, res, next) => {
    try {
        const errors = validationResult(req).formatWith(validationFailures);; 
        if (!errors.isEmpty()) {
            res.status(422).json({ errors: errors.array() });
            return;
        }
        const vehicle = await Vehicle.delete_vehicle(req.body);
        if(vehicle) {
            res.status(200).json({error: 0, status:1, message: "Vehicle deleted successfully."}); 
        } else {
            res.status(200).json({error: 1, status:1, message: "Provided data doesn't match with our records."});  
        }
    } catch (error) {
        if (!error.statusCode) {
            error.statusCode = 500
        }
        next(error);
    }
};





