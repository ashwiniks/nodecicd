const express = require("express");
const authController = require("../controller/authController");
const is_auth = require('../middleware/is_auth');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const dest = path.join(__dirname, '../..', 'pic');

router.post('/sign_up',authController.validate('signup'),authController.signUp);
router.get('/verify',authController.verifyToken);
router.post('/signIn',authController.validate('signin'),authController.signIn);
router.post('/profileUpdate',is_auth,authController.validate('profileupdate'),authController.profileUpdate);
router.post('/signupBelowThirteen',authController.validate('signupbelowthirteen'),authController.signupBelowThirteen);
router.post('/clear_login_Data',authController.clearLoginData);
module.exports = router;