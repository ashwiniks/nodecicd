var express = require('express');
var router = express.Router();
const adminController = require('../controller/adminController');

// Route for admin login
router.post('/login',adminController.validate('login'),adminController.signIn);

router.get('/app-comment',adminController.appComment);

router.post('/send-email',adminController.sendEmail);

router.post('/block_unblock_user',adminController.blockUser);  //is_block =1 for block ,and 0 for unblock


router.get('/block_user_list',adminController.blockedUsers);  //list of blocked user

router.get('/pending_request',adminController.pendingRequest);  //list of pending request

router.post('/pending_request_approve_reject',adminController.pendingRequestApproveReject);  //approve and reject pending request

router.get('/pending_request_history',adminController.pendingRequestHistory);  //list of pending request








module.exports = router;

