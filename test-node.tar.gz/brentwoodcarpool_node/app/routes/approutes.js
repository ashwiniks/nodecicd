var express = require('express');
var router = express.Router();
var todoList = require('../controller/appController');
const is_auth = require('../middleware/is_auth');
var user = require('../controller/userController');
//const is_auth = require('../middleware/is_auth');
const  vehicleController = require('../controller/vehicleController');
const  contactUsController = require('../controller/contactUsController');
const authController = require('../controller/authController');

router.get('/tasks', todoList.list_all_tasks);
router.post('/request_ride',is_auth, user.validate('request_ride'), user.request_ride);
router.post('/offer_ride',is_auth,user.validate('offer_ride'),user.offer_ride);
router.post('/cancel_ride',is_auth,user.validate('cancel_ride'),user.cancel_ride);
router.get('/listRequestRide',is_auth,user.validate('list_request_ride'),user.list_request_ride);
router.get('/listOfferRide',is_auth,user.validate('list_offer_ride'),user.list_offer_ride);
router.post('/new_request',is_auth,user.validate('new_request'),user.new_request);
router.post('/acceptRide',is_auth,user.validate('accept_ride'),user.accept_ride);
router.post('/cancel_find_ride',is_auth,user.validate('cancel_find_ride'),user.cancel_find_ride);
router.post('/schedule_rides',is_auth,user.validate('schedule_rides'),user.schedule_rides);
router.post('/pick_user',is_auth,user.validate('pick_user'),user.pick_user);
router.post('/drop_user',is_auth,user.validate('pick_user'),user.drop_user);
router.post('/add_driver',is_auth,user.validate('add_driver'),user.add_driver);


// route for  vehicle 
router.get('/getVehicle',vehicleController.getVehicle);
router.post('/add_vehicle', vehicleController.validate('add_vehicle'),vehicleController.addVehicle);
router.post('/delete_vehicle',is_auth, vehicleController.validate('delete_vehicle'),vehicleController.delete_vehicle);
router.post('/updateVehicle/:id', vehicleController.validate('update_vehicle'),vehicleController.updateVehicle);

// Route for contact us.
router.post('/contactUs',is_auth,contactUsController.validate('contact_us'),contactUsController.contact_us);
router.post('/feedback',is_auth,contactUsController.validate('feedback'),contactUsController.feedback);


// FCM notification
/*var FCM = require('fcm-node') ;
var serverKey = require('../middleware/brentwoodcarpoolandroid-7a3bd-firebase-adminsdk-on8fu-274f20e646.json') ; //put server key here

router.post('/pushmessage', function (req, res) {
	var fcm = new FCM(serverKey);
    var token = "";// put token here which user you have to send push notification
    var message = {
        to: token,
        collapse_key: 'Testing on web',
        notification: {title: 'hello', body: 'test'},
        data: {my_key: 'my value', contents: "abcv/"}
    };
    fcm.send(message, function (err, response) {
        if (err) {
            res.json({status: 0, message: err});
        } else {
            res.json({status: 1, message: response});
        }
    });
});

// Subscribe notification with Brentwood
router.post('/subscribe', function (req, res) {
	// Device token can be single or multiple
	var fcm = new FCM(serverKey);
	fcm.subscribeToTopic([ 'device_token_1', 'device_token_2' ], 'some_topic_name', (err, res) => {
	    assert.ifError(err);
	    assert.ok(res);
	    done();
	});
});	

// Unsubscribe nofification with Brentwood
router.post('/unsubscribe', function (req, res) {
	var fcm = new FCM(serverKey);
	fcm.unsubscribeToTopic([ 'device_token_1', 'device_token_2' ], 'some_topic_name', (err, res) => {
	    assert.ifError(err);
	    assert.ok(res);
	    done();
	});
});*/



// FCM notification ends here.





module.exports = router;

