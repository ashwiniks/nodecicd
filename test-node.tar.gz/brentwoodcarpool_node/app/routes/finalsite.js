var express = require('express')
var router = express.Router();
var btoa = require('btoa');
const axios = require('axios');


router.post('/adminLogin',function(req, res){
	
	var session_url = 'http://demo.finalsite.com/apidemo/api/apilogin/apilogin.cfm?ReturnFormat=json';
	var username = 'brentwood';
	var password = '5995414';
	var credentials = 'Basic ' + btoa(username + ':' + password);
	var basicAuth = 'Basic ' + credentials;
	let params = new URLSearchParams();
	params.append('ApiEncryptedKey', 'B1980E26792FC8F009A40D8B02FAA7F02FCF9082E3253193430A9C9A8DF7BFF0')
    
    axios.post(session_url, params, {
    	auth: {
			username: 'brentwood',
			password: '5995414'
		}
    }).then(function(response) {
    	res.send(JSON.parse(JSON.stringify(response.data.Result.ResultSet)));
    	console.log(JSON.stringify(response.data.Result.ResultSet));
	}).catch(function(error) {
		console.log(error) ;
		console.log('Error on Authentication');
	});
});

module.exports = router;
