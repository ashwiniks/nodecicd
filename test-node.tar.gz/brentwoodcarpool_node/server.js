require('dotenv').config() ;
const express = require('express');
const fs =  require('fs');
//const dateFormat = require('dateformat');
const path = require('path');
 const app = express();
 const multer = require('multer');
  app.use(express.static(path.join(__dirname, 'pic')));
const connection = require('./db.js');
const bodyParser = require('body-parser');
//const csv = require('csvtojson');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');
app.use(express.static(path.join(__dirname, 'app/profile_pic')));
//app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use( (request, response, next) => {
    response.header("Access-Control-Allow-Origin", "*");
    response.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,authorization");
    next();
});
const userRoutes = require('./app/routes/approutes');
const finalRoutes = require('./app/routes/finalsite');
const authRoutes = require('./app/routes/auth');
const adminRoutes = require('./app/routes/adminroutes');
const expressValidator = require('express-validator');

app.use('/user', userRoutes);
app.use('/finalsite', finalRoutes);
app.use('/auth', authRoutes);
app.use('/admin', adminRoutes);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(expressValidator());


app.get('/test',(req,res,next)=>{
    /*var FCM = require('fcm-node')
    
    var serverKey = require('./app/middleware/brentwoodcarpoolandroid-7a3bd-firebase-adminsdk-on8fu-274f20e646.json') //put the generated private key path here    
    
    var fcm = new FCM(serverKey)
 
    var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
        to: 'registration_token', 
        //collapse_key: '',
        
        notification: {
            title: 'Title of your push notification', 
            body: 'Body of your push notification' 
        },
        
        data: {  //you can send only notification or only data(or include both)
            my_key: 'my value',
            my_another_key: 'my another value'
        }
    }
    
    fcm.send(message, function(err, response){
        if (err) {
            console.log(err) ;
            console.log("Something has gone wrong!")
        } else {
            console.log("Successfully sent with response: ", response)
        }
    })*/
});


//custom validation middleware
app.use((error,req,res,next)=>{
    console.log(error);
    let status = error.statusCode;
    let message = error.message;
    //res.status(status).json({"errorMessagess":message});
	res.status(status).json({errorMessage:message});
    });
    
//port = process.env.PORT || 8083;

port = process.env.PORT || 1013;
app.listen(port);

